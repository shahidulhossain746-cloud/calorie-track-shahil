# Calorie & Workout Tracker (Local-only)

This is a Next.js 14 app (App Router) designed for **local-only** usage — data is stored in `localStorage`.

## Features
- Choose workout type & plan (Gym / Home)
- Auto-generated weekly plan previews
- Add meals and workouts (stored locally)
- Simple progress score based on logged items

## Run locally
1. `npm i`
2. `npm run dev`

## Deploy to Vercel
- Push repo to GitHub and import on https://vercel.com/new
- Vercel auto-detects Next.js and builds with `npm run build`.
