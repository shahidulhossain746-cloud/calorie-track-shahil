'use client'
import React from 'react'
import { useLocalState } from '../utils/useLocalState'

export default function ProgressView(){
  const [meals] = useLocalState('app:meals', [])
  const [workouts] = useLocalState('app:workouts', [])
  const [profile] = useLocalState('user:profile', {})

  // Simple heuristic: progress score based on activity + calories logged
  const activityScore = Math.min(100, workouts.length * 10)
  const nutritionScore = Math.max(0, 100 - (meals.reduce((s,m)=>s+m.cals,0) - 2000)/20)
  const overall = Math.round((activityScore * 0.6) + (nutritionScore * 0.4))

  return (
    <section>
      <h2>Your Progress</h2>
      <p><strong>Plan:</strong> {profile.planId || 'Not set'}</p>

      <div style={{ marginTop: 12 }}>
        <div style={{ background: '#eee', height: 14, borderRadius: 10, overflow: 'hidden' }}>
          <div style={{ width: `${overall}%`, height: '100%', background: '#4ade80' }} />
        </div>
        <p style={{ marginTop: 8 }}>Score: {overall}% — based on {workouts.length} workouts and {meals.length} meals logged.</p>
      </div>

      <h3 style={{ marginTop: 20 }}>Tips</h3>
      <ul>
        <li>Log workouts consistently — progress improves with consistency.</li>
        <li>Track meals roughly— set a daily calorie target in future versions.</li>
      </ul>
    </section>
  )
}
