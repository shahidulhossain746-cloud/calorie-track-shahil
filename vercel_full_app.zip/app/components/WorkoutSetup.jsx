'use client'
import React from 'react'
import { useLocalState } from '../utils/useLocalState'

const PLANS = {
  'gym': [
    { id: 'gym_full_2_3', label: '2 / 3 days (Full body split)' },
    { id: 'gym_5_6', label: '5 / 6 days (2 body parts per day)' },
    { id: 'gym_intense', label: 'Intense (6 days, body-part focused)' }
  ],
  'home': [
    { id: 'home_full', label: 'Home - Full body 3x week' },
    { id: 'home_split', label: 'Home - 4 day split' }
  ]
}

export default function WorkoutSetup({ onDone }){
  const [profile, setProfile] = useLocalState('user:profile', { workoutType: null, planId: null })

  function choose(type){
    setProfile({ ...profile, workoutType: type, planId: null })
  }
  function choosePlan(id){
    setProfile({ ...profile, planId: id })
  }

  return (
    <section>
      <h2>Choose your workout type</h2>
      <div style={{ display: 'flex', gap: 12, marginBottom: 12 }}>
        <button onClick={()=>choose('gym')} style={card}>{profile.workoutType==='gym' ? '✓ Gym' : 'Gym'}</button>
        <button onClick={()=>choose('home')} style={card}>{profile.workoutType==='home' ? '✓ Home' : 'Home'}</button>
      </div>

      {profile.workoutType && (
        <div>
          <h3>Choose plan</h3>
          <div style={{ display: 'flex', gap: 8 }}>
            {PLANS[profile.workoutType].map(p=> (
              <button key={p.id} onClick={()=>choosePlan(p.id)} style={{ ...card, borderColor: profile.planId===p.id ? '#333' : '#ddd' }}>{p.label}</button>
            ))}
          </div>
        </div>
      )}

      <div style={{ marginTop: 18 }}>
        <button onClick={onDone} style={{ padding: '10px 14px', borderRadius: 8 }}>Save & Continue</button>
      </div>

      <hr style={{ marginTop: 20 }} />
      <h3>Plan preview</h3>
      <PlanPreview profile={profile} />
    </section>
  )
}

function PlanPreview({ profile }){
  if(!profile.workoutType) return <p style={{ color: '#666' }}>Pick a workout type to preview generated plan.</p>
  const plan = generatePlan(profile.planId || '')
  return (
    <div>
      <p><strong>Selected:</strong> {profile.planId || '—'}</p>
      <ol>
        {plan.map((d,i)=> <li key={i}>Day {i+1}: {d.join(', ')}</li>)}
      </ol>
    </div>
  )
}

// Simple generator to return arrays of exercises/body parts for 7 days
function generatePlan(planId){
  const fullBody = ['Squat','Push','Pull','Hinge','Core','Rows','Press','Lunge','Pullup','Dip','Plank','Farmer\'s carry','Facepull']
  if(planId.startsWith('gym_full')){
    // create 3 day rotation using slices
    return [fullBody.slice(0,6), fullBody.slice(6,12), fullBody.slice(0,6), fullBody.slice(6,12), fullBody.slice(0,6), fullBody.slice(6,12), ['Active rest']]
  }
  if(planId==='gym_5_6'){
    return [['Chest','Triceps'],['Back','Biceps'],['Legs','Shoulders'],['Chest','Triceps'],['Back','Biceps'],['Legs','Shoulders'],['Rest']]
  }
  if(planId==='gym_intense'){
    return [['Chest'],['Back'],['Legs'],['Shoulders'],['Arms'],['Core'],['Rest']]
  }
  if(planId.startsWith('home')){
    return [['Full body'],['Full body'],['Rest'],['Full body'],['Light cardio'],['Mobility'],['Rest']]
  }
  return [['Rest'],['Rest'],['Rest'],['Rest'],['Rest'],['Rest'],['Rest']]
}

const card = { padding: '10px 12px', borderRadius: 8, border: '1px solid #ddd', background: '#fff' }
