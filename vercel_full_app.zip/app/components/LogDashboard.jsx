'use client'
import React, { useState } from 'react'
import { useLocalState } from '../utils/useLocalState'

export default function LogDashboard(){
  const [meals, setMeals] = useLocalState('app:meals', [])
  const [workouts, setWorkouts] = useLocalState('app:workouts', [])
  const [newMeal, setNewMeal] = useState({ name: '', cals: '' })
  const [newWorkout, setNewWorkout] = useState({ name: '', duration: '' })

  function addMeal(){
    if(!newMeal.name || !newMeal.cals) return
    setMeals([{ id: Date.now(), ...newMeal, cals: Number(newMeal.cals) }, ...meals])
    setNewMeal({ name:'', cals:'' })
  }
  function addWorkout(){
    if(!newWorkout.name || !newWorkout.duration) return
    setWorkouts([{ id: Date.now(), ...newWorkout, duration: Number(newWorkout.duration) }, ...workouts])
    setNewWorkout({ name:'', duration:'' })
  }

  function removeMeal(id){ setMeals(meals.filter(m=>m.id!==id)) }
  function removeWorkout(id){ setWorkouts(workouts.filter(w=>w.id!==id)) }

  return (
    <section>
      <h2>Logs</h2>
      <div style={{ display: 'flex', gap: 20 }}>
        <div style={{ flex: 1 }}>
          <h3>Add meal</h3>
          <input placeholder="Meal name" value={newMeal.name} onChange={e=>setNewMeal({...newMeal, name:e.target.value})} style={input} />
          <input placeholder="Calories" value={newMeal.cals} onChange={e=>setNewMeal({...newMeal, cals:e.target.value})} style={input} />
          <button onClick={addMeal} style={btn}>Add meal</button>

          <ul>
            {meals.map(m=> (
              <li key={m.id} style={{ marginTop: 8 }}>
                {m.name} — {m.cals} kcal <button onClick={()=>removeMeal(m.id)} style={linkBtn}>Remove</button>
              </li>
            ))}
          </ul>
        </div>

        <div style={{ flex: 1 }}>
          <h3>Add workout</h3>
          <input placeholder="Workout (e.g. Day 1 - Chest)" value={newWorkout.name} onChange={e=>setNewWorkout({...newWorkout, name:e.target.value})} style={input} />
          <input placeholder="Duration (mins)" value={newWorkout.duration} onChange={e=>setNewWorkout({...newWorkout, duration:e.target.value})} style={input} />
          <button onClick={addWorkout} style={btn}>Add workout</button>

          <ul>
            {workouts.map(w=> (
              <li key={w.id} style={{ marginTop: 8 }}>
                {w.name} — {w.duration} min <button onClick={()=>removeWorkout(w.id)} style={linkBtn}>Remove</button>
              </li>
            ))}
          </ul>
        </div>
      </div>

      <hr style={{ marginTop: 20 }} />
      <h3>Quick summary</h3>
      <Summary meals={meals} workouts={workouts} />
    </section>
  )
}

function Summary({ meals, workouts }){
  const totalCals = meals.reduce((s,m)=>s+m.cals, 0)
  const totalMins = workouts.reduce((s,w)=>s+w.duration, 0)
  return (
    <div>
      <p>Total meals today: {meals.length} — {totalCals} kcal</p>
      <p>Total workout sessions: {workouts.length} — {totalMins} minutes</p>
    </div>
  )
}

const input = { display: 'block', padding: '8px 10px', marginTop: 8, borderRadius: 6, border: '1px solid #ddd', width: '100%' }
const btn = { marginTop: 10, padding: '8px 12px', borderRadius: 8 }
const linkBtn = { marginLeft: 8, color: '#b00', background: 'none', border: 'none', cursor: 'pointer' }
