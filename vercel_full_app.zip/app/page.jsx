'use client'
import React from 'react'
import { useLocalState } from './utils/useLocalState'
import WorkoutSetup from './components/WorkoutSetup'
import LogDashboard from './components/LogDashboard'
import ProgressView from './components/ProgressView'

export default function Page(){
  const [view, setView] = useLocalState('app:view', 'setup')
  return (
    <main>
      <nav style={{ marginBottom: 20 }}>
        <button onClick={()=>setView('setup')} style={navBtnStyle}>Setup</button>
        <button onClick={()=>setView('logs')} style={navBtnStyle}>Logs</button>
        <button onClick={()=>setView('progress')} style={navBtnStyle}>Progress</button>
      </nav>

      {view === 'setup' && <WorkoutSetup onDone={()=>setView('logs')} />}
      {view === 'logs' && <LogDashboard />}
      {view === 'progress' && <ProgressView />}
    </main>
  )
}

const navBtnStyle = { marginRight: 8, padding: '8px 12px', borderRadius: 6, border: '1px solid #ddd', background: '#fafafa' }
