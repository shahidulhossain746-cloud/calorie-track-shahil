export const metadata = {
  title: "Calorie & Workout Tracker",
  description: "Local-first calorie tracker and workout planner",
}

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body style={{ fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial', margin: 0 }}>
        <div style={{ maxWidth: 900, margin: '0 auto', padding: 20 }}>
          <header style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
            <h1 style={{ margin: 0 }}>Calorie & Workout Tracker</h1>
            <small style={{ color: '#666' }}>Local-only (stored in browser)</small>
          </header>
          {children}
          <footer style={{ marginTop: 40, color: '#777', fontSize: 13 }}>
            Built with ♥ — local-only data (no account)
          </footer>
        </div>
      </body>
    </html>
  )
}
