export const metadata = { title: "Workout App" };
export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body style={{ fontFamily: 'sans-serif', padding:20 }}>{children}</body>
    </html>
  );
}
